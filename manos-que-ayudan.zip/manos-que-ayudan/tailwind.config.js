/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Fondo neutro y cálido
        surface: "#F8F9FA",
        // Texto editorial
        ink: "#1F2937",
        // Único color de acento (verde hoja calmo)
        accent: {
          DEFAULT: "#2E5A44",
          soft: "#E7EFE9", // fondo suave para chips seleccionados
          hover: "#254A38",
        },
        border: "#E5E7EB",
        muted: "#6B7280",
      },
      borderRadius: {
        card: "1rem",
        chip: "999px",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
